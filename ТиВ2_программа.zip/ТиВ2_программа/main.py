import caesar


def encrypt():
    text = input("введите текст: ")
    shift = int(input("введите сдвиг: "))
    print("результат: " + caesar.caesar_encrypt(text, shift))


def decrypt():
    text = input("введите текст: ")
    shift = int(input("введите сдвиг: "))
    print("результат: " + caesar.caesar_decrypt(text, shift))


def brute_force():
    text = input("введите текст: ")
    print("результат: ")
    res = caesar.brute_force_decrypt(text)
    if isinstance(res, list):
        for line in res:
            print(f"{line[0]}\t{line[1]}")
    else:
        print(res)


print(" --- ШИФР ЦЕЗАРЯ ---")
while True:
    print("\n1 - шифровка")
    print("2 - дешифровка")
    print("3 - взломать текст")
    print("4 - выход")
    var = int(input("выберите действие: "))
    match var:
        case 1:
            encrypt()
        case 2:
            decrypt()
        case 3:
            brute_force()
        case 4:
            break
        case _:
            print("ошибка ввода")
