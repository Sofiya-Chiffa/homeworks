RUS_ALPHABET_LOWER = 'абевгдеёжзийклмнопрстуфхцчшщъыьэюя'
RUS_ALPHABET_UPPER = RUS_ALPHABET_LOWER.upper()
ENG_ALPHABET_LOWER = 'abcdefghijklmnopqrstuvwxyz'
ENG_ALPHABET_UPPER = ENG_ALPHABET_LOWER.upper()

# нормализация сдвига, так чтобы он не выходил за рамки самого короткого из алфавитов
def normalize_shift(shift):
    return shift % 26

# проверка, что текст не пустой и это строка
def is_valid_text(text):
    if not isinstance(text, str):
        return False
    return len(text) > 0

# сдвиг одного символа
def _shift_char(char, shift):
    alphabets = [
        (ENG_ALPHABET_LOWER, ENG_ALPHABET_UPPER),
        (RUS_ALPHABET_LOWER, RUS_ALPHABET_UPPER),
    ]
    for lower, upper in alphabets:
        if char in lower:
            i = (lower.index(char) + shift) % len(lower)
            return lower[i]
        if char in upper:
            i = (upper.index(char) + shift) % len(upper)
            return upper[i]
    return char

# шифрование
def caesar_encrypt(text, shift):
    if not is_valid_text(text):
        return "Текст не должен быть пустой строкой"
    shift = normalize_shift(shift)
    return ''.join(_shift_char(ch, shift) for ch in text)

# дешифрование
def caesar_decrypt(text, shift):
    if not is_valid_text(text):
        return "Текст не должен быть пустой строкой"
    shift = normalize_shift(shift)
    return ''.join(_shift_char(ch, -shift) for ch in text)

# взлом методом грубой силы
def brute_force_decrypt(text):
    if not is_valid_text(text):
        return "Текст не должен быть пустой строкой"
    return [(shift, caesar_decrypt(text, shift)) for shift in range(26)]
